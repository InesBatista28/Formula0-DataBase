namespace ProjetoFBD
{
    partial class TeamMemberForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // TeamMemberForm
            // 
            this.ClientSize = new System.Drawing.Size(1400, 700);
            this.Name = "TeamMemberForm";
            this.Text = "Team Members Management";
            this.ResumeLayout(false);
        }
    }
}
