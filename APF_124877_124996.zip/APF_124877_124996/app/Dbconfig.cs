using System;

namespace ProjetoFBD
{
    public static class DbConfig
    {
        public const string ConnectionString =
            "Server=mednat.ieeta.pt,8101;" +
            "Database=p3g9;" +
            "User Id=p3g9;" +
            "Password=MQ_IB_FBD_2526;" +
            "TrustServerCertificate=True;";
    }
}