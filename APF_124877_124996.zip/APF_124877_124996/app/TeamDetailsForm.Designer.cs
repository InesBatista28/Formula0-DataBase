namespace ProjetoFBD
{
    partial class TeamDetailsForm
    {
        // Variável de designer necessária.
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // TeamDetailsForm
            // 
            this.ClientSize = new System.Drawing.Size(600, 700);
            this.Name = "TeamDetailsForm";
            this.Text = "Team Details";
            this.ResumeLayout(false);
        }

        #endregion
    }
}
