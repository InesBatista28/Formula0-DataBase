namespace ProjetoFBD
{
    partial class GPListForm
    {
        // Variável de designer necessária.
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // GPListForm
            // 
            this.ClientSize = new System.Drawing.Size(300, 300);
            this.Name = "GPListForm";
            this.ResumeLayout(false);
        }

        #endregion
    }
}