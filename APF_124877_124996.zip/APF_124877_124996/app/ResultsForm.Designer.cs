namespace ProjetoFBD
{
    partial class ResultsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // ResultsForm
            // 
            this.ClientSize = new System.Drawing.Size(1400, 700);
            this.Name = "ResultsForm";
            this.Text = "Session Results Management";
            this.ResumeLayout(false);
        }
    }
}
