namespace ProjetoFBD
{
    partial class TeamForm
    {
        // Variável de designer necessária.
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // TeamForm
            // 
            this.ClientSize = new System.Drawing.Size(1200, 700);
            this.Name = "TeamForm";
            this.Text = "Teams Management";
            this.ResumeLayout(false);
        }

        #endregion
    }
}
